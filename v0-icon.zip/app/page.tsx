import V0ParticleAnimation from "@/components/v0-particle-animation"

export default function Home() {
  return (
    <main className="min-h-screen bg-black">
      <V0ParticleAnimation />
    </main>
  )
}
